function resize_iframe(){     
	document.getElementById("frmnagvis").style.height=parseInt(window.frames['frmnagvis'].document.body.scrollHeight)+"px";
}
