-- 19/12/2008
-- Write here your installation queries
-- Topology insert for menu level 1, level 2 and level 3

INSERT INTO `topology` (`topology_id`, `topology_name`, `topology_icone`, `topology_parent`, `topology_page`, `topology_order`, `topology_group`, `topology_url`, `topology_url_opt`, `topology_popup`, `topology_modules`, `topology_show`) VALUES ('', 'Nagvis', NULL, 4, 403, 20, 1, './modules/nagvis/nagvis.php', NULL, '0', '1', '1');
